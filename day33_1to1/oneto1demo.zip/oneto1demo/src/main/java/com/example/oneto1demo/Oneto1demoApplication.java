package com.example.oneto1demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Oneto1demoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Oneto1demoApplication.class, args);
	}

}
