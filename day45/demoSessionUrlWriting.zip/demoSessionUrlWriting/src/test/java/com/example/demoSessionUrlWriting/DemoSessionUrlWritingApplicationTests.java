package com.example.demoSessionUrlWriting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSessionUrlWritingApplicationTests {

	@Test
	void contextLoads() {
	}

}
