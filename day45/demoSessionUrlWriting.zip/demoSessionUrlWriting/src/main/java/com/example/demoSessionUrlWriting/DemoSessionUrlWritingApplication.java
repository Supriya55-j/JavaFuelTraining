package com.example.demoSessionUrlWriting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSessionUrlWritingApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSessionUrlWritingApplication.class, args);
	}

}
