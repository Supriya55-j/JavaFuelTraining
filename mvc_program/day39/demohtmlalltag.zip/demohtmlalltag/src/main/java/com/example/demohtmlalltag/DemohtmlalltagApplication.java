package com.example.demohtmlalltag;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemohtmlalltagApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemohtmlalltagApplication.class, args);
	}

}
