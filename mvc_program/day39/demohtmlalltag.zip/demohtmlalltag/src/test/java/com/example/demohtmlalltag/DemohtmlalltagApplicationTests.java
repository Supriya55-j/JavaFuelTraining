package com.example.demohtmlalltag;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemohtmlalltagApplicationTests {

	@Test
	void contextLoads() {
	}

}
