package com.example.demomvchtml1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demomvchtml1Application {

	public static void main(String[] args) {
		SpringApplication.run(Demomvchtml1Application.class, args);
	}

}
