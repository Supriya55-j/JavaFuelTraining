package com.example.one2onedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class One2onedemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(One2onedemoApplication.class, args);
	}

}
