package com.example.demospringsecurity1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demospringsecurity1Application {

	public static void main(String[] args) {
		SpringApplication.run(Demospringsecurity1Application.class, args);
	}

}
