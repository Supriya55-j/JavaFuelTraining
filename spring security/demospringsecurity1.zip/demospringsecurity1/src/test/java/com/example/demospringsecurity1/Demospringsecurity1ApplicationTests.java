package com.example.demospringsecurity1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demospringsecurity1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
