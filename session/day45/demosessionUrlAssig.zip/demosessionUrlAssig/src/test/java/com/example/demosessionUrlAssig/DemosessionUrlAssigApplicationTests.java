package com.example.demosessionUrlAssig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemosessionUrlAssigApplicationTests {

	@Test
	void contextLoads() {
	}

}
