package com.example.demosessionUrlAssig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemosessionUrlAssigApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemosessionUrlAssigApplication.class, args);
	}

}
