package com.example.demohttpmethods1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demohttpmethods1Application {

	public static void main(String[] args) {
		SpringApplication.run(Demohttpmethods1Application.class, args);
	}

}
