package com.example.demosession;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemosessionApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemosessionApplication.class, args);
	}

}
